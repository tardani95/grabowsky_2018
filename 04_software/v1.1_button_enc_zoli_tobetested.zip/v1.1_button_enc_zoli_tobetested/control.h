#ifndef _CONTROL_H

#define _CONTROL_H


#include "periph.h"

void TIM4_IRQHandler(void);










#endif
