#include "stm32f10x.h"



#include "conf.h"
#include "periph.h"
#include "util.h"
#include "control.h"



int main(void)
{
	SystemInit();

	InitPeriph();
	InitNav();
/*
	uint16_t ledPins[4]={	PIN_D_RS,
								PIN_D_RF,
								PIN_D_LF,
								PIN_D_LS};
	GPIO_TypeDef* ledPorts[4]={PORT_D_RS,
								PORT_D_RF,
								PORT_D_LF,
								PORT_D_LS};
*/

    while(1){
    }
}



























