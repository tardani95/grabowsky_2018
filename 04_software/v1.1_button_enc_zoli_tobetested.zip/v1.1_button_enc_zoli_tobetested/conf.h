/* basic defines for controlling misc. functions */

#ifndef _UTIL_H
#define _UTIL_H

#define _DEBUG
//#define _DEBUG_MCO


#endif
